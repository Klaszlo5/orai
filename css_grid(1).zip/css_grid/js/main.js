/*1.  Írj egy reguláris kifejezést, amely felismeri az alábbi szövegben az összes olyan szót, amely "ing"-re végződik!
* \b - szóhatár
* \w+ - Legalább egy alfanumerikus karakter
* ing - Pontosan 'ing' végződés
* g - Globális mód, hogy az összes találatot megtalálja
* */
const text = 'I am singing while cooking and dancing';
const regex = /\b\w+ing\b/g;
console.log(text.match(regex));
/*2. Írj egy reguláris kifejezést, amely megállapítja, hogy egy adott szöveg tartalmaz-e csak számokat!
* ^ - szöveg elejére horgonyoz
* \d+ - Egy vagy több számjegy
* $ - A szöveg végére horgonyoz
* */
const text1 = '12345';
const text2 = '123456abc';
const regexNumeric = /^\d+$/;
console.log(regexNumeric.test(text1))
console.log(regexNumeric.test(text2))
/* 3. E-mail validálás */
console.log('Email Regex:')
const email1 = 'admin@admin.info';
const email2 = 'email@hu';
const regexEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
console.log(regexEmail.test(email1));
console.log(regexEmail.test(email2));