﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSONData.Models
{
    internal class Animal
    {
        public string Name { get; }
        public string Breed { get; }
        public int Age { get; }

        public Animal(string name, string breed, int age)
        {
            Name = name;
            Breed = breed;
            Age = age;
        }
    }

}
