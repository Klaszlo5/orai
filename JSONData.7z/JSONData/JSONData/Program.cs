﻿using JSONData.Models;
using Newtonsoft.Json.Linq;

namespace JSONData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Zoo zoo = new Zoo()
            {
                Name = "Afrikai állatkert",
                City = "Dakar"
            };

            zoo.Owner = new Person()
            {
                Name = "Kiss Andrea",
                IsWomen = true,
                Age = 32,
            };

            zoo.Animals.AddFirst(new Animal("Jack", "Oroszlán", 3));
            zoo.Animals.AddFirst(new Animal("John", "Gorilla", 4));
            zoo.Animals.AddFirst(new Animal("Jill", "Makákó", 1));

            /*
             DataContractJsonSerializer

             Newtonsoft.JSON
                JObject
                JArray
                JToken
             */

            JObject json = new JObject();
            json.Add("name", zoo.Name);
            json.Add("city", zoo.City);

            JObject owner_json = new JObject();
            owner_json.Add("name", zoo.Owner.Name);
            owner_json.Add("age", zoo.Owner.Age);
            owner_json.Add("is_women", zoo.Owner.IsWomen);
            json.Add("owner", owner_json);

            JArray array = new JArray();
            foreach (Animal animal in zoo.Animals) { 
                JObject animalJson = new JObject();
                animalJson.Add("name", animal.Name);
                animalJson.Add("breed", animal.Breed);
                animalJson.Add("age", animal.Age);

                array.Add(animalJson);
            }
            json.Add("animals", array);

            Console.WriteLine(json.ToString());

        }
    }
}
