const baseUrl = "http://localhost:8000/api/skyscrapers"

async function fetchSkyscrapers() {
    try {
        const response = await fetch(baseUrl);
        const data = await response.json();
        const tableBody = document.getElementById("skyscraper-list");
        tableBody.innerHTML = "";
        data.forEach((item) => {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.location}</td>
            <td>
            <button type="button" class="btn btn-info btn-sm"  onclick="showSkyscraperDetails(${item.id})">Részletek</button>
            <button type="button" class="btn btn-warning btn-sm" onclick="editSkyscraper(${item.id})">Szerkesztés</button>
            <button type="button" class="btn btn-danger btn-sm" onclick="deleteSkyscraper(${item.id})">Törlés</button>
</td>
`
            tableBody.appendChild(row);
        })
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}
document.getElementById('add-button').addEventListener('click', async ()=>{
    const newSykscraper = {
        name: document.getElementById("name").value,
        location: document.getElementById("location").value,
        height: parseInt(document.getElementById("height").value),
        floors: parseInt(document.getElementById("floors").value),
        year_completed: parseInt(document.getElementById("year").value)
    }
    try{
        const response = await fetch(baseUrl,{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(newSykscraper)
        });
        if (response.ok){
            await fetchSkyscrapers();
            document.getElementById("add-form").reset();
            const addModal = bootstrap.Modal.getInstance(document.getElementById("addModal"));
            addModal.hide();
        }
    }catch (error){
        console.error("Error adding data", error)
    }
})
function showSkyscraperDetails(id) {
}

function editSkyscraper(id) {

}

function deleteSkyscraper(id) {

}

fetchSkyscrapers();