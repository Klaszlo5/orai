﻿using System.Diagnostics;

namespace ExtMet
{
    public static class StringExtensions {
        // Kiterjesztő metódus
        public static int CountSpaces(this string input) {
            if (string.IsNullOrEmpty(input)) {
                return 0;
            }
            return input.Split(' ').Length - 1;
        }

        public static bool ContainsNumber(this string input) {
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    return true;
                }
            }
            return false;
        }
    }

    public static class IntExtensions {
        public static int Double(this int number)
        { 
            return number * 2;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            string text = "Az ipafai papnak fapipája van mert az ipafai fapipa pai fapipa";

            Console.WriteLine(text);
            Console.WriteLine(text.CountSpaces());
            Console.WriteLine(text.ContainsNumber());

            Console.WriteLine();
            Console.WriteLine();

            string text2 = "Szöveg ami tartalmaz 1 számot..";
            Console.WriteLine(text2);
            Console.WriteLine(text2.CountSpaces());
            Console.WriteLine(text2.ContainsNumber());

            Console.WriteLine();
            Console.WriteLine();

            int number = 5;

            Console.WriteLine(number);
            Console.WriteLine(number.Double());
        }
    }
}
