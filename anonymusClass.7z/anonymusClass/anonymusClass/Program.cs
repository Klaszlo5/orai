﻿namespace anonymusClass
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var person = new { 
                Name = "John Doe", 
                Age = 43 
            };

            Console.WriteLine($"Name:{person.Name}, Age:{person.Age}");

            var students = new[] {
                new { Name = "Gábor", Age = 14 },
                new { Name = "Anna", Age = 13 },
                new { Name = "Ádám", Age = 14 },
            };

            foreach (var student in students)
            {
                Console.WriteLine(student.Age);
            }
        }
    }
}
