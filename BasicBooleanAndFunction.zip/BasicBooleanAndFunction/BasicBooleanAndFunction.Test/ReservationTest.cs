﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicBooleanAndFunction.Test
{
    [TestFixture]
    internal class ReservationTest
    {
        [Test]
        [Ignore("Ha nem akarod futtatni a tesztet akkor ezt kikkel tolteni az indokkal")]
        public void CanBeCancelledBy_UserIsAdmin_ReturnsTrue()
        {
            // Arrange
            Reservation reservation = new Reservation();
            // Act
            bool result = reservation.CanBeCancelledBy(new User() { IsAdmin = true });
            // Assert
            Assert.That(result, Is.True);
        }
        [Test]
        public void CanBeCancelledBy_SameUserCancellingTheReservation_ReturnsTrue()
        {
            User user = new User(); 
            Reservation reservation = new Reservation() { MadeBy = user };

            bool result = reservation.CanBeCancelledBy(user);

            Assert.That(result, Is.True);
        }
        [Test]
        public void CanBeCancelledBy_AnotherUserCancellingTheReservation_ReturnsFalse()
        {
            Reservation reservation = new Reservation() { MadeBy = new User() };
            bool result = reservation.CanBeCancelledBy(new User());
            Assert.That(result, Is.False);
        }
    }
}
