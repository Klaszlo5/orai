﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicBooleanAndFunction
{
    public class Reservation
    {
        public User MadeBy { get; set; }
        public bool CanBeCancelledBy(User user)
        {
            if (user.IsAdmin)
            {
                return true;
            }
            else if (this.MadeBy == user)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
