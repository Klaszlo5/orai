﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDD.Application.Exceptions;
using TDD.Services;

namespace TDD.Test.Services
{
    [TestFixture]
    public class OrderServiceTest
    {
        private readonly Mock<ILoggerService> _consoleLoggerServiceMock = new Mock<ILoggerService>();
        private readonly OrderService _orderService;
        public OrderServiceTest()
        {
            _orderService = new OrderService(_consoleLoggerServiceMock.Object);
        }
        [SetUp]
        public void SetUp()
        {
            _consoleLoggerServiceMock.Reset();
        }
        [Test]
        public void CreateOrder_InvokesLog_Success()
        {
            _orderService.CreateOrder(productId: 1);

            _consoleLoggerServiceMock.Verify(a => a.Log("Order created"), Times.Once);
        }
       [Test]
       public void CreateOrder_InvalidProductId_ShouldThrowProductNotFoundException()
        {
            Assert.Throws<ProductNotFoundException>(()=>_orderService.CreateOrder(productId: -1));
        }
        [Test]
        public void CreateOrder_ValidProductId_CreatedANewOrder()
        {
            Assert.DoesNotThrow(() => _orderService.CreateOrder(productId: 1));
        }
        [Test]
        public void DeleteOrder_InvokesLog_Success()
        {
            _orderService.DeleteOrder(orderId: 1);

            _consoleLoggerServiceMock.Verify(a => a.Log("Order deleted"), Times.Once);
        }

        [Test]
        public void DeleteOrder_InvalidOrderId_ShouldThrow()
        {
            Assert.Throws<OrderNotFoundException>(() => _orderService.DeleteOrder(orderId: -1));
        }

        [Test]
        public void DeleteOrder_Success()
        {
            Assert.DoesNotThrow(() => _orderService.DeleteOrder(orderId: 1));
        }
    }
}
