﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDD.Services;

namespace TDD.Test.Services
{
    [TestFixture]
    public class ConsoleLoggerServiceTest
    {
        private ILoggerService _loggerService;
        [SetUp]
        public void SetUp()
        {
            _loggerService = new ConsoleLoggerService();
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void Log_EmptyMessage_ShouldThrowArgumentNullException(string? message)
        {
            Assert.Throws<ArgumentNullException>(() => _loggerService.Log(message));
        }
        [Test]
        public void Log_MessageWithValue_ShouldNotThrowException()
        {
            Assert.DoesNotThrow(() => _loggerService.Log("random message"));
        }
    }
}
