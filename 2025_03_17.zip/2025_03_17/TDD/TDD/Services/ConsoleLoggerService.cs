﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDD.Services
{
    public class ConsoleLoggerService : ILoggerService
    {
        public void Log(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                throw new ArgumentNullException(nameof(message));
            }
            Console.WriteLine(message);
        }
    }
}
