﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDD.Application.Exceptions;

namespace TDD.Services
{
    public class OrderService : IOrderService
    {
        private readonly ILoggerService _loggerService;
        public OrderService(ILoggerService loggerService)
        {
            this._loggerService = loggerService;
        }
        public int CreateOrder(int productId)
        {
            if (productId <= 0) 
            {
                throw new ProductNotFoundException();
            }
            _loggerService.Log("Order created");
            return 1;
        }

        public void DeleteOrder(int orderId)
        {
            if (orderId <= 0) 
            {
                throw new OrderNotFoundException();
            }
            _loggerService.Log("Order deleted");
        }
    }
}
