﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQueries.Models
{
    internal class Order
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }
        public List<Product> Products { get; set; } //linkedlist?
        public decimal TotalPrice {
            get {
                return Products.Sum(product => product.Price);            
            }
        }

        public bool HaveExpensiceProduct {
            get { return Products.Any(p => p.Price > 350000) ; }
        }
    }
}
