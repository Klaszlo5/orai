﻿using LINQueries.Models;

namespace LINQueries
{
    internal class Program
    {
        /*
         LINQ - Language Integrated Queries
            + Szintaktikailag egyszerű
            + Forrásfüggetlen

         LINQ to Objects 
         LINQ to XML
         LINQ to JSON
         LINQ to Entities

         Kapcsolód eszközök
            - Lambda
            - var kulcsszó és névtelen osztályok
            - Extension methods - kiegészítő metódusok
            + LINQ operátorok
            + Procedurális/DEKLERATÍV

        List<>, XML  -> IEnumerable extension methods -> Func/Predicate -> (IEnumerable)

        Adatbázis -> IQueryable extension methods


        Példa funkciók:
            - Elemkiválasztás       SELECT
            - Szűrés                WHERE
            - Rendezés              ORDERBY
            - Csoportosítás         GROUPBY



         */

        static void Main(string[] args)
        {
            var x = 6;
            //var z = new Zoo();

            var ZooData = new { 
                Name = "Afrikai állatkert",
                City = "Dakar"
            };

            Console.WriteLine(ZooData.GetType());


            //WHERE
            List<int> list = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

            //var evenNumbers = list.Where(IsEvenNumber);
            var evenNumbers = list.Where(n => n % 2 == 0);

            Console.WriteLine("Páros számok:");
            foreach (int i in evenNumbers) {
                Console.WriteLine(i);
            }


            List<Customer> customers = new List<Customer>
            {
                new Customer
                {
                    Id = 1,
                    Name = "Kántor Tamás",
                    City = "Budaörs",
                    Orders = new List<Order> {
                        new Order {
                            Id = 101,
                            OrderDate = new DateTime(2024,5,21),
                            Products = new List<Product> {
                                new Product { Id = 1, Name = "Billentyűzet", Price=20000 },
                                new Product { Id = 2, Name = "Laptop", Price=300000 }
                            }
                        },
                        new Order {
                            Id = 102,
                            OrderDate = new DateTime(2024,6,15),
                            Products = new List<Product> {
                                new Product { Id = 3, Name = "Egér", Price=4000 },
                                new Product { Id = 4, Name = "Monitor", Price=50000 }
                            }
                        }
                    }
                },
                new Customer { 
                    Id = 2,
                    Name = "Csordás Anna",
                    City = "Hatvan",
                    Orders = new List<Order> {
                        new Order { 
                            Id = 103,
                            OrderDate = new DateTime(2024,7,18),
                            Products = new List<Product> { 
                                new Product { Id = 5, Name="Iróasztal", Price= 150000 },
                                new Product { Id = 6, Name="Gamer szék", Price=400000}
                            }
                        }
                    }
                },
                new Customer { 
                    Id = 3,
                    Name = "Kovács Szilveszter",
                    City = "Hatvan",
                    Orders = new List<Order>()
                }
            };

            Console.WriteLine();
            Console.WriteLine("CUSTOMERS");

            /*
             WHERE 
                amire hívható:  IEnumrable<T> (List<T>, LinkedList<T>, Array<T>)
                paramétere LAMBDA: Funct<T, bool> ~ Predicate<T>   Vár egy lista elemeivel megegyező típusú paramétert, igaz/hamist ad vissza
                        Az a dolga, hogy az adott elemről eldöntse, hogy bekerüljön e a szűrésbe
                eredmény: IEnumerable<T>
                T paraméter a listából dől el, a folyamat során fix típus
                
                Lambda kifejezés meghívódik minden elemre, ha az eredmény TRUE akkor a kimenetbe kerül az adott elem, különbe nem.
             */

            Console.WriteLine();
            Console.WriteLine("customersInHatvan");
            var customersInHatvan = customers.Where(customer => customer.City == "Hatvan");
            foreach (var customer in customersInHatvan)
            {
                Console.WriteLine($" - {customer.Name} ({customer.City})");
            }

            Console.WriteLine();
            Console.WriteLine("customersStartingWithK");
            var customersStartingWithK = customers.Where(customer => customer.Name.StartsWith("K"));
            foreach (var customer in customersStartingWithK)
            {
                Console.WriteLine($" - {customer.Name} ({customer.City})");
            }

            /*
             SelectMany
             */

            //összes rendelés összegyüjtése
            Console.WriteLine();
            Console.WriteLine("Rendelések:");
            var allOrder = customers.SelectMany(customer => customer.Orders);
            foreach (var order in allOrder)
            {
                Console.WriteLine($" - {order.Id} ({order.OrderDate})");
            }

            //összes termék összegyüjtése
            Console.WriteLine();
            Console.WriteLine("Termékek:");
            var allProduct = customers.SelectMany(
                    customer => customer.Orders.SelectMany(order => order.Products)
                    );
            foreach (var product in allProduct)
            {
                Console.WriteLine($" - {product.Name} ({product.Price}) [{product.Id}]");
            }

            //összes termék id lekérése
            Console.WriteLine();
            Console.WriteLine("Termék id-k:");
            var allProductId = customers.SelectMany(c => c.Orders.SelectMany(o => o.Products).Select(p => p.Id));
            foreach (var id in allProductId)
            {
                Console.Write($"{id}, ");
            }

            //összes rendelés lekérése (de csak azonosító és összed leképzeése)
            Console.WriteLine();
            Console.WriteLine("Rendelés azonosító-összeg párosok:");
            var allOrderIdPrice = customers.SelectMany(c => c.Orders).Select(order => new { order.Id, order.TotalPrice });
            foreach (var order in allOrderIdPrice)
            {
                Console.WriteLine($" - {order.Id}>>{order.TotalPrice}");
            }

            //rendelések adott időszakból
            Console.WriteLine();
            var startDate = new DateTime(2024, 6, 1);
            var endDate = new DateTime(2024, 8, 1);
            Console.WriteLine($"OrdersInDates ({startDate} - {endDate}) :");
            var ordersInDates = customers.SelectMany(c => c.Orders).Where(o => o.OrderDate > startDate && o.OrderDate < endDate);
            foreach (var order in ordersInDates)
            {
                Console.WriteLine($" - {order.Id} :: {order.OrderDate} [{order.TotalPrice}]");
                Console.WriteLine("\tTermékek:");
                foreach (var product in order.Products) {
                    Console.WriteLine($"\t - {product.Name} ({product.Price})");
                }
            }

            //rendelések, melyben 100.000 fölötti áru termékek vannak
            Console.WriteLine();
            Console.WriteLine("orderWithExpesiveProduct (>100000)");
            var orderWithExpesiveProduct = customers.SelectMany(c => c.Orders).Where(o => o.Products.Any(p=>p.Price > 100000));
            foreach (var order in orderWithExpesiveProduct)
            {
                Console.WriteLine($" - {order.Id} :: {order.OrderDate} [{order.TotalPrice}]");
                Console.WriteLine("\tTermékek:");
                foreach (var product in order.Products.Where(p=>p.Price>100000))
                {
                    Console.WriteLine($"\t - {product.Name} ({product.Price})");
                }
            }

            //ügyfelek, akik rendeltek 350000 fölötti áru terméket
            Console.WriteLine();
            Console.WriteLine("customersWithExpensiveProduct (>350000)");
            var customersWithExpensiveProduct = customers.Where(c=>c.Orders.Any(o=>o.Products.Any(p=>p.Price>350000)));
            foreach (var customer in customersWithExpensiveProduct)
            {
                Console.WriteLine($" - {customer.Name} [{customer.City}]");
            }

            //ügyfelek, akik rendeltek 350000 fölötti áru terméket (Order HaveExpensive tulajdonsággal)
            Console.WriteLine();
            Console.WriteLine("customersWithExpensiveProduct (>350000)");
            var customersWithExpensiveProduct2 = customers.Where(c => c.Orders.Any(o=>o.HaveExpensiceProduct));
            foreach (var customer in customersWithExpensiveProduct)
            {
                Console.WriteLine($" - {customer.Name} [{customer.City}]");
            }

        }
        /* the dont do example ÁLMOS!
        private static bool IsEvenNumber(int number) { 
            return number % 2 == 0;
        }
        */
    }
}
